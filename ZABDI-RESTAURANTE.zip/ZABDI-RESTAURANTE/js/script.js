/* ZABDI RESTAURANTE - FUNCIONES */
document.addEventListener("DOMContentLoaded", () => {
  // Año automático del pie de página
  const currentYear = document.getElementById("currentYear");
  if (currentYear) currentYear.textContent = new Date().getFullYear();

  // Efecto de navegación al desplazarse
  const navbar = document.getElementById("navbar");
  function updateNavbar() {
    if (navbar) navbar.classList.toggle("scrolled", window.scrollY > 50);
  }
  window.addEventListener("scroll", updateNavbar);
  updateNavbar();

  // Filtro de comidas y bebidas
  const categoryButtons = document.querySelectorAll(".category-button");
  const products = document.querySelectorAll(".product-item");

  function filterProducts(category) {
    products.forEach(product => {
      product.hidden = product.dataset.category !== category;
    });

    categoryButtons.forEach(button => {
      const active = button.dataset.category === category;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  categoryButtons.forEach(button => {
    button.addEventListener("click", () => {
      filterProducts(button.dataset.category);
    });
  });

  filterProducts("comidas");

  // Cerrar menú móvil al seleccionar una sección
  const navigationLinks = document.querySelectorAll(
    "#navbarMenu .nav-link, #navbarMenu .nav-button"
  );
  const navbarMenu = document.getElementById("navbarMenu");

  navigationLinks.forEach(link => {
    link.addEventListener("click", () => {
      if (navbarMenu && navbarMenu.classList.contains("show") && window.bootstrap) {
        bootstrap.Collapse.getOrCreateInstance(navbarMenu).hide();
      }
    });
  });

  // Botón volver arriba
  const backToTop = document.getElementById("backToTop");
  function updateBackToTop() {
    if (backToTop) backToTop.classList.toggle("show", window.scrollY > 450);
  }
  window.addEventListener("scroll", updateBackToTop);
  updateBackToTop();

  if (backToTop) {
    backToTop.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // Animaciones de entrada
  const animatedElements = document.querySelectorAll(
    ".section-heading, .about-photo, .about .col-lg-6, " +
    ".product-card, .gallery-item, .location-info, .location-card"
  );

  animatedElements.forEach(element => element.classList.add("reveal"));

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries, observerInstance) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observerInstance.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    animatedElements.forEach(element => observer.observe(element));
  } else {
    animatedElements.forEach(element => element.classList.add("visible"));
  }

  console.log("ZABDI Restaurante iniciado correctamente.");
});
